package com.example.androidretrofitupload.Download;

/**
 * Created by SONU on 29/10/15.
 */
public class Utils {

    //String Values to be Used in App
    public static final String downloadDirectory = "Androhub Downloads";
    public static final String mainUrl = "http://10.30.4.121/upload/assets";
    public static final String downloadPdfUrl = "http://10.30.4.121/upload/assets/Hello.png";
}
