package com.example.androidretrofitupload.Utils;

 public interface UploadCallBacks {
    void onProgressUpdate(int percentage);
}
